const glibc = process.report?.getReport().header.glibcVersionRuntime;
const [major, minor] = (glibc || "0.0").split(".").map(Number);
const useNative = process.env.LIGHTNINGCSS_FORCE_WASM !== "1" && process.platform === "linux" && process.arch === "x64" && (major > 2 || (major === 2 && minor >= 35));
const native = useNative ? require("../lightningcss.linux-x64-gnu.node") : require("../wasm/wasm-node.cjs");
module.exports.nativeFixBackend = useNative ? "native" : "wasm";
module.exports.transform = wrap(native.transform);
module.exports.transformStyleAttribute = wrap(native.transformStyleAttribute);
module.exports.bundle = wrap(native.bundle);
module.exports.bundleAsync = wrap(native.bundleAsync);
module.exports.browserslistToTargets = require('./browserslistToTargets');
module.exports.composeVisitors = require('./composeVisitors');
module.exports.Features = require('./flags').Features;

function wrap(call) {
  return (options) => {
    if (typeof options.visitor === 'function') {
      let deps = [];
      options.visitor = options.visitor({
        addDependency(dep) {
          deps.push(dep);
        }
      });

      let result = call(options);
      if (result instanceof Promise) {
        result = result.then(res => {
          if (deps.length) {
            res.dependencies ??= [];
            res.dependencies.push(...deps);
          }
          return res;
        });
      } else if (deps.length) {
        result.dependencies ??= [];
        result.dependencies.push(...deps);
      }
      return result;
    } else {
      return call(options);
    }
  };
}
