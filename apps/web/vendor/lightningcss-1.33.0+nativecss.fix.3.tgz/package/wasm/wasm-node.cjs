var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// ../../../../../tmp/native-css-fix-20261111/built-wasm-fix3/wasm-node.mjs
var wasm_node_exports = {};
__export(wasm_node_exports, {
  Features: () => Features,
  browserslistToTargets: () => browserslistToTargets,
  bundle: () => bundle,
  bundleAsync: () => bundleAsync,
  composeVisitors: () => composeVisitors,
  default: () => init,
  transform: () => transform,
  transformStyleAttribute: () => transformStyleAttribute
});
module.exports = __toCommonJS(wasm_node_exports);

// ../../../../../tmp/native-css-fix-20261111/built-wasm-fix3/import.meta.url-polyfill.js
var import_meta_url = typeof document === "undefined" ? new (require("url".replace("", ""))).URL("file:" + __filename).href : document.currentScript && document.currentScript.src || new URL("main.js", document.baseURI).href;

// ../../../../../tmp/native-css-fix-20261111/test-tools/node_modules/napi-wasm/index.mjs
var NAPI_OK = 0;
var NAPI_INVALID_ARG = 1;
var NAPI_STRING_EXPECTED = 3;
var NAPI_NUMBER_EXPECTED = 6;
var NAPI_BOOLEAN_EXPECTED = 7;
var NAPI_GENERIC_FAILURE = 9;
var NAPI_PENDING_EXCEPTION = 10;
var NAPI_CANCELED = 11;
var NAPI_HANDLE_SCOPE_MISMATCH = 13;
var NAPI_BIGINT_EXPECTED = 17;
var NAPI_NO_EXTERNAL_BUFFERS_ALLOWED = 22;
var NAPI_WRITABLE = 1 << 0;
var NAPI_ENUMERABLE = 1 << 1;
var NAPI_CONFIGURABLE = 1 << 2;
var NAPI_STATIC = 1 << 10;
var typedArrays = [
  Int8Array,
  Uint8Array,
  Uint8ClampedArray,
  Int16Array,
  Uint16Array,
  Int32Array,
  Uint32Array,
  Float32Array,
  Float64Array,
  BigInt64Array,
  BigUint64Array
];
var environments = [];
var Environment = class {
  scopes = [];
  referenceId = 1;
  references = /* @__PURE__ */ new Map();
  deferred = [null];
  wrappedObjects = /* @__PURE__ */ new WeakMap();
  externalObjects = /* @__PURE__ */ new WeakMap();
  buffers = /* @__PURE__ */ new Map();
  instanceData = 0;
  pendingException = null;
  constructor(instance2) {
    this.id = environments.length;
    environments.push(this);
    this.instance = instance2;
    this.table = instance2.exports.__indirect_function_table;
    this.exports = {};
    this.pushScope();
    let values = this.scopes[this.scopes.length - 1];
    let exports2 = values.length;
    values.push(this.exports);
    try {
      if (this.instance.exports.napi_register_module_v1) {
        this.instance.exports.napi_register_module_v1(this.id, exports2);
      }
      if (this.instance.exports.napi_register_wasm_v1) {
        this.instance.exports.napi_register_wasm_v1(this.id, exports2);
      }
    } finally {
      this.popScope();
      if (this.pendingException) {
        let e = this.pendingException;
        this.pendingException = null;
        throw e;
      }
    }
  }
  destroy() {
    environments[this.id] = void 0;
  }
  getString(ptr, len = strlen(this.memory, ptr)) {
    return decoder.decode(this.memory.subarray(ptr, Math.max(0, ptr + len)));
  }
  pushScope() {
    let id = this.scopes.length;
    this.scopes.push(id ? [...this.scopes[id - 1]] : [void 0, null, globalThis, true, false]);
    return id;
  }
  popScope() {
    this.scopes.pop();
    for (let [buffer, slice] of this.buffers) {
      if (buffer.byteLength && slice.byteLength) {
        buffer.set(slice);
      }
    }
    this.buffers.clear();
  }
  get(idx) {
    return this.scopes[this.scopes.length - 1][idx];
  }
  set(idx, value) {
    this.scopes[this.scopes.length - 1][idx] = value;
  }
  pushValue(value, scope = this.scopes.length - 1) {
    let values = this.scopes[scope];
    let id = values.length;
    values.push(value);
    return id;
  }
  createValue(value, result, scope) {
    if (typeof value === "boolean") {
      this.setPointer(result, value ? 3 : 4);
      return NAPI_OK;
    } else if (typeof value === "undefined") {
      this.setPointer(result, 0);
      return NAPI_OK;
    } else if (value === null) {
      this.setPointer(result, 1);
      return NAPI_OK;
    } else if (value === globalThis) {
      this.setPointer(result, 2);
      return NAPI_OK;
    }
    let id = this.pushValue(value, scope);
    this.setPointer(result, id);
    return NAPI_OK;
  }
  setPointer(ptr, value) {
    this.u32[ptr >> 2] = value;
    return NAPI_OK;
  }
  _u32 = new Uint32Array();
  get u32() {
    if (this._u32.byteLength === 0) {
      this._u32 = new Uint32Array(this.instance.exports.memory.buffer);
    }
    return this._u32;
  }
  _i32 = new Int32Array();
  get i32() {
    if (this._i32.byteLength === 0) {
      this._i32 = new Int32Array(this.instance.exports.memory.buffer);
    }
    return this._i32;
  }
  _u16 = new Uint16Array();
  get u16() {
    if (this._u16.byteLength === 0) {
      this._u16 = new Uint16Array(this.instance.exports.memory.buffer);
    }
    return this._u16;
  }
  _u64 = new BigUint64Array();
  get u64() {
    if (this._u64.byteLength === 0) {
      this._u64 = new BigUint64Array(this.instance.exports.memory.buffer);
    }
    return this._u64;
  }
  _i64 = new BigInt64Array();
  get i64() {
    if (this._i64.byteLength === 0) {
      this._i64 = new BigInt64Array(this.instance.exports.memory.buffer);
    }
    return this._i64;
  }
  _f64 = new Float64Array();
  get f64() {
    if (this._f64.byteLength === 0) {
      this._f64 = new Float64Array(this.instance.exports.memory.buffer);
    }
    return this._f64;
  }
  _buf = new Uint8Array();
  get memory() {
    if (this._buf.byteLength === 0) {
      this._buf = new Uint8Array(this.instance.exports.memory.buffer);
    }
    return this._buf;
  }
  getBufferInfo(buf2, ptr) {
    if (this.buffers.has(buf2)) {
      let b2 = this.buffers.get(buf2);
      this.setPointer(ptr, b2.byteOffset);
      return b2.byteLength;
    }
    if (buf2 instanceof ArrayBuffer) {
      let b2 = this.copyBuffer(new Uint8Array(buf2));
      this.setPointer(ptr, b2.byteOffset);
      return b2.byteLength;
    }
    if (buf2.buffer === this.instance.exports.memory.buffer) {
      this.setPointer(ptr, buf2.byteOffset);
      return buf2.byteLength;
    }
    let b = this.copyBuffer(new Uint8Array(buf2.buffer, buf2.byteOffset, buf2.byteLength));
    this.setPointer(ptr, b.byteOffset);
    return b.byteLength;
  }
  copyBuffer(data) {
    let ptr = this.instance.exports.napi_wasm_malloc(data.byteLength);
    let mem = this.memory;
    mem.set(data, ptr);
    let buf2 = mem.subarray(ptr, ptr + data.byteLength);
    let finalize = (_env, data2) => {
      if (this.instance.exports.napi_wasm_free) {
        this.instance.exports.napi_wasm_free(data2);
      }
    };
    finalizationRegistry.register(buf2, new FinalizeRecord(this.id, finalize, 0, ptr));
    this.buffers.set(data, buf2);
    return buf2;
  }
  createFunction(cb, data) {
    let env3 = this;
    let fn = env3.table.get(cb);
    let func = function(...args) {
      let scope = env3.pushScope();
      try {
        let values = env3.scopes[scope];
        let info = values.length;
        values.push({
          thisArg: this,
          args,
          data,
          newTarget: new.target
        });
        let res = fn(env3.id, info);
        return env3.get(res);
      } finally {
        env3.popScope();
        if (env3.pendingException) {
          let e = env3.pendingException;
          env3.pendingException = null;
          throw e;
        }
      }
    };
    return func;
  }
  readPropertyDescriptor(ptr) {
    let buf2 = this.u32;
    let utf8name = buf2[ptr++];
    let nameValue = buf2[ptr++];
    let method = buf2[ptr++];
    let getter = buf2[ptr++];
    let setter = buf2[ptr++];
    let val = buf2[ptr++];
    let attrs = buf2[ptr++];
    let data = buf2[ptr++];
    let name = utf8name ? this.getString(utf8name) : this.get(nameValue);
    let writable = Boolean(attrs & NAPI_WRITABLE);
    let enumerable = Boolean(attrs & NAPI_ENUMERABLE);
    let configurable = Boolean(attrs & NAPI_CONFIGURABLE);
    let isStatic = Boolean(attrs & NAPI_STATIC);
    let get = getter ? this.createFunction(getter, data) : void 0;
    let set = setter ? this.createFunction(setter, data) : void 0;
    let value = method ? this.createFunction(method, data) : val ? this.get(val) : void 0;
    let descriptor = {
      name,
      static: isStatic,
      configurable,
      enumerable
    };
    if (get || set) {
      descriptor.get = get;
      descriptor.set = set;
    } else if (value) {
      descriptor.writable = writable;
      descriptor.value = value;
    }
    return descriptor;
  }
};
var decoder = new TextDecoder("utf-8", { ignoreBOM: true, fatal: true });
var latin1Decoder = new TextDecoder("latin1");
var utf16Decoder = new TextDecoder("utf-16");
var encoder = new TextEncoder();
var FinalizeRecord = class {
  constructor(env3, finalize, hint, data) {
    this.env = env3;
    this.finalize = finalize;
    this.hint = hint;
    this.data = data;
  }
};
var finalizationRegistry = new FinalizationRegistry((buffer) => {
  if (buffer.finalize) {
    buffer.finalize(buffer.env, buffer.data, buffer.hint);
  }
});
var ExternalValue = class {
};
var threadsafeFunctions = [];
var ThreadSafeFunction = class {
  constructor(env3, fn, nativeFn, context) {
    this.env = env3;
    this.fn = fn;
    this.nativeFn = nativeFn;
    this.context = context;
    this.id = threadsafeFunctions.length;
    threadsafeFunctions.push(this);
  }
};
var asyncWork = [null];
var AsyncWork = class {
  constructor(env3, execute, complete, data) {
    this.env = env3;
    this.execute = execute;
    this.complete = complete;
    this.data = data;
    this.id = asyncWork.length;
    asyncWork.push(this);
  }
};
var napi = {
  napi_open_handle_scope(env_id, result) {
    let env3 = environments[env_id];
    let id = env3.pushScope();
    return env3.setPointer(result, id);
  },
  napi_close_handle_scope(env_id, scope) {
    let env3 = environments[env_id];
    if (scope !== env3.scopes.length - 1) {
      return NAPI_HANDLE_SCOPE_MISMATCH;
    }
    env3.popScope();
    return NAPI_OK;
  },
  napi_open_escapable_handle_scope(env_id, result) {
    let env3 = environments[env_id];
    let id = env3.pushScope();
    return env3.setPointer(result, id);
  },
  napi_close_escapable_handle_scope(env_id, scope) {
    let env3 = environments[env_id];
    if (scope !== env3.scopes.length - 1) {
      return NAPI_HANDLE_SCOPE_MISMATCH;
    }
    env3.popScope();
    return NAPI_OK;
  },
  napi_escape_handle(env_id, scope_id, escapee, result) {
    let env3 = environments[env_id];
    let value = env3.get(escapee);
    return env3.createValue(value, result, scope_id - 1);
  },
  napi_create_object(env_id, result) {
    let env3 = environments[env_id];
    return env3.createValue({}, result);
  },
  napi_set_property(env_id, object, key, value) {
    let env3 = environments[env_id];
    let obj = env3.get(object);
    let name = env3.get(key);
    let val = env3.get(value);
    obj[name] = val;
    return NAPI_OK;
  },
  napi_get_property(env_id, object, key, result) {
    let env3 = environments[env_id];
    let obj = env3.get(object);
    let name = env3.get(key);
    return env3.createValue(obj[name], result);
  },
  napi_delete_property(env_id, object, key, result) {
    let env3 = environments[env_id];
    let obj = env3.get(object);
    let name = env3.get(key);
    let res = false;
    try {
      res = delete obj[name];
    } catch (err) {
    }
    if (result) {
      env3.memory[result] = res ? 1 : 0;
    }
    return NAPI_OK;
  },
  napi_has_property(env_id, object, key, result) {
    let env3 = environments[env_id];
    let obj = env3.get(object);
    let name = env3.get(key);
    env3.memory[result] = name in obj ? 1 : 0;
    return NAPI_OK;
  },
  napi_has_own_property(env_id, object, key, result) {
    let env3 = environments[env_id];
    let obj = env3.get(object);
    let name = env3.get(key);
    env3.memory[result] = obj.hasOwnProperty(name) ? 1 : 0;
    return NAPI_OK;
  },
  napi_set_named_property(env_id, object, utf8Name, value) {
    let env3 = environments[env_id];
    let obj = env3.get(object);
    let val = env3.get(value);
    let name = env3.getString(utf8Name);
    obj[name] = val;
    return NAPI_OK;
  },
  napi_get_named_property(env_id, object, utf8Name, result) {
    let env3 = environments[env_id];
    let obj = env3.get(object);
    let name = env3.getString(utf8Name);
    return env3.createValue(obj[name], result);
  },
  napi_has_named_property(env_id, object, utf8Name, result) {
    let env3 = environments[env_id];
    let obj = env3.get(object);
    let name = env3.getString(utf8Name);
    env3.memory[result] = name in obj ? 1 : 0;
    return NAPI_OK;
  },
  napi_get_property_names(env_id, object, result) {
    let env3 = environments[env_id];
    let obj = env3.get(object);
    let properties = Object.keys(obj);
    return env3.createValue(properties, result);
  },
  napi_get_all_property_names(env_id, object, key_mode, key_filter, key_conversion, result) {
    throw new Error("not implemented");
  },
  napi_define_properties(env_id, object, property_count, properties) {
    let env3 = environments[env_id];
    let obj = env3.get(object);
    let ptr = properties >> 2;
    for (let i = 0; i < property_count; i++) {
      let descriptor = env3.readPropertyDescriptor(ptr);
      Object.defineProperty(obj, descriptor.name, descriptor);
      ptr += 8;
    }
    return NAPI_OK;
  },
  napi_object_freeze(env_id, object) {
    let env3 = environments[env_id];
    let obj = env3.get(object);
    Object.freeze(obj);
    return NAPI_OK;
  },
  napi_object_seal(env_id, object) {
    let env3 = environments[env_id];
    let obj = env3.get(object);
    Object.seal(obj);
    return NAPI_OK;
  },
  napi_get_prototype(env_id, object, result) {
    let env3 = environments[env_id];
    let obj = env3.get(object);
    return env3.createValue(Object.getPrototypeOf(obj), result);
  },
  napi_define_class(env_id, utf8name, length, constructor, data, property_count, properties, result) {
    let env3 = environments[env_id];
    let func = env3.createFunction(constructor, data);
    Object.defineProperty(func, "name", {
      value: env3.getString(utf8name, length),
      configurable: true
    });
    let ptr = properties >> 2;
    for (let i = 0; i < property_count; i++) {
      let descriptor = env3.readPropertyDescriptor(ptr);
      if (descriptor.static) {
        Object.defineProperty(func, descriptor.name, descriptor);
      } else {
        Object.defineProperty(func.prototype, descriptor.name, descriptor);
      }
      ptr += 8;
    }
    return env3.createValue(func, result);
  },
  napi_create_reference(env_id, value, refcount, result) {
    let env3 = environments[env_id];
    let id = env3.referenceId++;
    env3.references.set(id, {
      value: env3.get(value),
      refcount
    });
    return env3.setPointer(result, id);
  },
  napi_delete_reference(env_id, ref) {
    let env3 = environments[env_id];
    env3.references.delete(ref);
    return NAPI_OK;
  },
  napi_get_reference_value(env_id, ref, result) {
    let env3 = environments[env_id];
    let reference = env3.references.get(ref);
    return env3.createValue(reference.value, result);
  },
  napi_reference_ref(env_id, ref, result) {
    let env3 = environments[env_id];
    let reference = env3.references.get(ref);
    reference.refcount++;
    return env3.setPointer(result, reference.refcount);
  },
  napi_reference_unref(env_id, ref, result) {
    let env3 = environments[env_id];
    let reference = env3.references.get(ref);
    if (reference.refcount === 0) {
      return NAPI_GENERIC_FAILURE;
    }
    reference.refcount--;
    return env3.setPointer(result, reference.refcount);
  },
  napi_add_env_cleanup_hook() {
    return NAPI_OK;
  },
  napi_remove_env_cleanup_hook() {
    return NAPI_OK;
  },
  napi_add_async_cleanup_hook() {
    return NAPI_OK;
  },
  napi_remove_async_cleanup_hook() {
    return NAPI_OK;
  },
  napi_set_instance_data(env_id, data, finalize_cb, finalize_hint) {
    let env3 = environments[env_id];
    env3.instanceData = data;
    return NAPI_OK;
  },
  napi_get_instance_data(env_id, data) {
    let env3 = environments[env_id];
    return env3.setPointer(data, env3.instanceData);
  },
  napi_get_boolean(env_id, value, result) {
    let env3 = environments[env_id];
    return env3.setPointer(result, value ? 3 : 4);
  },
  napi_get_value_bool(env_id, value, result) {
    let env3 = environments[env_id];
    let val = env3.get(value);
    if (typeof val !== "boolean") {
      return NAPI_BOOLEAN_EXPECTED;
    }
    env3.memory[result] = val ? 1 : 0;
    return NAPI_OK;
  },
  napi_create_int32(env_id, value, result) {
    let env3 = environments[env_id];
    return env3.createValue(value, result);
  },
  napi_get_value_int32(env_id, value, result) {
    let env3 = environments[env_id];
    let val = env3.get(value);
    if (typeof val !== "number") {
      return NAPI_NUMBER_EXPECTED;
    }
    env3.i32[result >> 2] = val;
    return NAPI_OK;
  },
  napi_create_uint32(env_id, value, result) {
    let env3 = environments[env_id];
    return env3.createValue(value, result);
  },
  napi_get_value_uint32(env_id, value, result) {
    let env3 = environments[env_id];
    let val = env3.get(value);
    if (typeof val !== "number") {
      return NAPI_NUMBER_EXPECTED;
    }
    return env3.setPointer(result, val);
  },
  napi_create_int64(env_id, value, result) {
    let env3 = environments[env_id];
    return env3.createValue(Number(value), result);
  },
  napi_get_value_int64(env_id, value, result) {
    let env3 = environments[env_id];
    let val = env3.get(value);
    if (typeof val !== "number") {
      return NAPI_NUMBER_EXPECTED;
    }
    env3.i64[result >> 3] = val;
    return NAPI_OK;
  },
  napi_create_double(env_id, value, result) {
    let env3 = environments[env_id];
    return env3.createValue(value, result);
  },
  napi_get_value_double(env_id, value, result) {
    let env3 = environments[env_id];
    let val = env3.get(value);
    if (typeof val !== "number") {
      return NAPI_NUMBER_EXPECTED;
    }
    env3.f64[result >> 3] = val;
    return NAPI_OK;
  },
  napi_create_bigint_int64(env_id, value, result) {
    let env3 = environments[env_id];
    return env3.createValue(BigInt.asIntN(64, value), result);
  },
  napi_get_value_bigint_int64(env_id, value, result, lossless) {
    let env3 = environments[env_id];
    let val = env3.get(value);
    if (typeof val !== "bigint") {
      return NAPI_BIGINT_EXPECTED;
    }
    env3.i64[result >> 3] = val;
    if (lossless) {
      env3.memory[lossless] = BigInt.asIntN(64, val) === val ? 1 : 0;
    }
    return NAPI_OK;
  },
  napi_create_bigint_uint64(env_id, value, result) {
    let env3 = environments[env_id];
    return env3.createValue(BigInt.asUintN(64, value), result);
  },
  napi_get_value_bigint_uint64(env_id, value, result, lossless) {
    let env3 = environments[env_id];
    let val = env3.get(value);
    if (typeof val !== "bigint") {
      return NAPI_BIGINT_EXPECTED;
    }
    env3.u64[result >> 3] = val;
    if (lossless) {
      env3.memory[lossless] = BigInt.asUintN(64, val) === val ? 1 : 0;
    }
    return NAPI_OK;
  },
  napi_create_bigint_words(env_id, sign_bit, word_count, words, result) {
    let env3 = environments[env_id];
    let buf2 = env3.u64;
    let ptr = words >> 3;
    let res = 0n;
    let shift = 0n;
    for (let i = 0; i < word_count; i++) {
      let word = buf2[ptr++];
      res += word << shift;
      shift += 64n;
    }
    res *= BigInt((-1) ** sign_bit);
    return env3.createValue(res, result);
  },
  napi_get_value_bigint_words(env_id, value, sign_bit, word_count, words) {
    let env3 = environments[env_id];
    let val = env3.get(value);
    if (typeof val !== "bigint") {
      return NAPI_BIGINT_EXPECTED;
    }
    let count = env3.u32[word_count >> 2];
    if (sign_bit) {
      env3.i32[sign_bit] = val < 0n ? 1 : 0;
    }
    let i = 0;
    if (words) {
      let mask = (1n << 64n) - 1n;
      let buf2 = env3.u64;
      let ptr = words >> 3;
      if (val < 0n) {
        val = -val;
      }
      for (; i < count && val !== 0n; i++) {
        buf2[ptr++] = val & mask;
        val >>= 64n;
      }
    }
    while (val > 0n) {
      i++;
      val >>= 64n;
    }
    return env3.setPointer(word_count, i);
  },
  napi_get_null(env_id, result) {
    let env3 = environments[env_id];
    return env3.setPointer(result, 1);
  },
  napi_create_array(env_id, result) {
    let env3 = environments[env_id];
    return env3.createValue([], result);
  },
  napi_create_array_with_length(env_id, length, result) {
    let env3 = environments[env_id];
    return env3.createValue(new Array(length), result);
  },
  napi_set_element(env_id, object, index, value) {
    let env3 = environments[env_id];
    let obj = env3.get(object);
    let val = env3.get(value);
    obj[index] = val;
    return NAPI_OK;
  },
  napi_get_element(env_id, object, index, result) {
    let env3 = environments[env_id];
    let obj = env3.get(object);
    let val = obj[index];
    return env3.createValue(val, result);
  },
  napi_has_element(env_id, object, index, result) {
    let env3 = environments[env_id];
    let obj = env3.get(object);
    env3.memory[result] = obj.hasOwnProperty(index) ? 1 : 0;
    return NAPI_OK;
  },
  napi_delete_element(env_id, object, index, result) {
    let env3 = environments[env_id];
    let obj = env3.get(object);
    let res = false;
    try {
      res = delete obj[index];
    } catch (err) {
    }
    if (result) {
      env3.memory[result] = res ? 1 : 0;
    }
    return NAPI_OK;
  },
  napi_get_array_length(env_id, value, result) {
    let env3 = environments[env_id];
    let val = env3.get(value);
    return env3.setPointer(result, val.length);
  },
  napi_get_undefined(env_id, result) {
    let env3 = environments[env_id];
    return env3.setPointer(result, 0);
  },
  napi_create_function(env_id, utf8name, length, cb, data, result) {
    let env3 = environments[env_id];
    let func = env3.createFunction(cb, data);
    Object.defineProperty(func, "name", {
      value: env3.getString(utf8name, length),
      configurable: true
    });
    return env3.createValue(func, result);
  },
  napi_call_function(env_id, recv, func, argc, argv, result) {
    let env3 = environments[env_id];
    let thisArg = env3.get(recv);
    let fn = env3.get(func);
    let args = new Array(argc);
    let mem = env3.u32;
    for (let i = 0; i < argc; i++) {
      args[i] = env3.get(mem[argv >> 2]);
      argv += 4;
    }
    try {
      let res = fn.apply(thisArg, args);
      return env3.createValue(res, result);
    } catch (err) {
      env3.pendingException = err;
      return NAPI_PENDING_EXCEPTION;
    }
  },
  napi_new_instance(env_id, cons, argc, argv, result) {
    let env3 = environments[env_id];
    let Class = env3.get(cons);
    let args = new Array(argc);
    let mem = env3.u32;
    for (let i = 0; i < argc; i++) {
      args[i] = env3.get(mem[argv >> 2]);
      argv += 4;
    }
    try {
      let value = new Class(...args);
      return env3.createValue(value, result);
    } catch (err) {
      env3.pendingException = err;
      return NAPI_PENDING_EXCEPTION;
    }
  },
  napi_get_cb_info(env_id, cbinfo, argc, argv, thisArg, data) {
    let env3 = environments[env_id];
    let info = env3.get(cbinfo);
    env3.setPointer(argc, info.args.length);
    for (let i = 0; i < info.args.length; i++) {
      env3.createValue(info.args[i], argv);
      argv += 4;
    }
    env3.createValue(info.thisArg, thisArg);
    env3.setPointer(data, info.data);
    return NAPI_OK;
  },
  napi_get_new_target(env_id, cbinfo, result) {
    let env3 = environments[env_id];
    let info = env3.get(cbinfo);
    return env3.createValue(info.newTarget, result);
  },
  napi_create_threadsafe_function(env_id, func, async_resource, async_resource_name, max_queue_size, initial_thread_count, thread_finalize_data, thread_finalize_cb, context, call_js_cb, result) {
    let env3 = environments[env_id];
    let fn = func ? env3.get(func) : void 0;
    let cb = call_js_cb ? env3.table.get(call_js_cb) : void 0;
    let f = new ThreadSafeFunction(env3, fn, cb, context);
    if (thread_finalize_cb) {
      let cb2 = env3.table.get(thread_finalize_cb);
      finalizationRegistry.register(f, new FinalizeRecord(env_id, cb2, 0, f.id));
    }
    env3.setPointer(result, f.id);
    return NAPI_OK;
  },
  napi_ref_threadsafe_function() {
    return NAPI_OK;
  },
  napi_unref_threadsafe_function() {
    return NAPI_OK;
  },
  napi_acquire_threadsafe_function() {
    return NAPI_OK;
  },
  napi_release_threadsafe_function(func, mode) {
    threadsafeFunctions[func] = void 0;
    return NAPI_OK;
  },
  napi_call_threadsafe_function(func, data, is_blocking) {
    let f = threadsafeFunctions[func];
    f.env.pushScope();
    try {
      if (f.nativeFn) {
        let id = f.fn ? f.env.pushValue(f.fn) : 0;
        f.nativeFn(f.env.id, id, f.context, data);
      } else if (f.fn) {
        f.fn();
      }
    } finally {
      f.env.popScope();
    }
  },
  napi_get_threadsafe_function_context(func, result) {
    let f = threadsafeFunctions[func];
    f.env.setPointer(result, f.context);
    return NAPI_OK;
  },
  napi_create_async_work(env_id, async_resource, async_resource_name, execute, complete, data, result) {
    let env3 = environments[env_id];
    let executeFn = execute ? env3.table.get(execute) : void 0;
    let completeFn = complete ? env3.table.get(complete) : void 0;
    let w = new AsyncWork(env3, executeFn, completeFn, data);
    env3.setPointer(result, w.id);
    return NAPI_OK;
  },
  napi_delete_async_work(env3, work2) {
    asyncWork[work2] = void 0;
    return NAPI_OK;
  },
  napi_queue_async_work(env3, work2) {
    queueMicrotask(() => {
      let w = asyncWork[work2];
      if (w) {
        w.execute(env3, w.data);
        w.complete(env3, NAPI_OK, w.data);
      }
    });
    return NAPI_OK;
  },
  napi_cancel_async_work() {
    let w = asyncWork[work];
    w.complete(env, NAPI_CANCELED, w.data);
    asyncWork[work] = void 0;
    return NAPI_OK;
  },
  napi_throw(env_id, error) {
    let env3 = environments[env_id];
    env3.pendingException = env3.get(error);
    return NAPI_OK;
  },
  napi_throw_error(env_id, code, msg) {
    let env3 = environments[env_id];
    let err = new Error(env3.getString(msg));
    err.code = code;
    env3.pendingException = err;
    return NAPI_OK;
  },
  napi_throw_type_error(env_id, code, msg) {
    let env3 = environments[env_id];
    let err = new TypeError(env3.getString(msg));
    err.code = code;
    env3.pendingException = err;
    return NAPI_OK;
  },
  napi_throw_range_error(env_id, code, msg) {
    let env3 = environments[env_id];
    let err = new RangeError(env3.getString(msg));
    err.code = code;
    env3.pendingException = err;
    return NAPI_OK;
  },
  napi_create_error(env_id, code, msg, result) {
    let env3 = environments[env_id];
    let err = new Error(env3.get(msg));
    err.code = env3.get(code);
    return env3.createValue(err, result);
  },
  napi_create_type_error(env_id, code, msg, result) {
    let env3 = environments[env_id];
    let err = new TypeError(env3.get(msg));
    err.code = env3.get(code);
    return env3.createValue(err, result);
  },
  napi_create_range_error(env_id, code, msg, result) {
    let env3 = environments[env_id];
    let err = new RangeError(env3.get(msg));
    err.code = env3.get(code);
    return env3.createValue(err, result);
  },
  napi_get_and_clear_last_exception(env_id, result) {
    let env3 = environments[env_id];
    let e = env3.pendingException;
    env3.pendingException = null;
    return env3.createValue(e, result);
  },
  napi_is_exception_pending(env_id, result) {
    let env3 = environments[env_id];
    env3.memory[result] = env3.pendingException ? 1 : 0;
    return NAPI_OK;
  },
  napi_fatal_exception(env_id, err) {
    throw new Error("not implemented");
  },
  napi_fatal_error(location, location_len, message, message_len) {
    throw new Error("not implemented");
  },
  napi_get_global(env_id, result) {
    let env3 = environments[env_id];
    return env3.setPointer(result, 2);
  },
  napi_create_buffer(env_id, length, data, result) {
    let env3 = environments[env_id];
    let ptr = env3.instance.exports.napi_wasm_malloc(length);
    if (data) {
      env3.setPointer(data, ptr);
    }
    let buf2 = typeof globalThis.Buffer !== "undefined" ? globalThis.Buffer.from(env3.memory.buffer, ptr, length) : env3.memory.subarray(ptr, ptr + length);
    let finalize = (_env, data2) => {
      if (env3.instance.exports.napi_wasm_free) {
        env3.instance.exports.napi_wasm_free(data2);
      }
    };
    finalizationRegistry.register(buf2, new FinalizeRecord(env_id, finalize, 0, ptr));
    return env3.createValue(buf2, result);
  },
  napi_create_buffer_copy(env_id, length, data, result_data, result) {
    let env3 = environments[env_id];
    let ptr = env3.instance.exports.napi_wasm_malloc(length);
    env3.memory.set(env3.memory.subarray(data, data + length), ptr);
    if (result_data) {
      env3.setPointer(result_data, ptr);
    }
    let res = typeof globalThis.Buffer !== "undefined" ? globalThis.Buffer.from(env3.memory.buffer, ptr, length) : env3.memory.subarray(ptr, ptr + length);
    let finalize = (_env, data2) => {
      if (env3.instance.exports.napi_wasm_free) {
        env3.instance.exports.napi_wasm_free(data2);
      }
    };
    finalizationRegistry.register(buf, new FinalizeRecord(env_id, finalize, 0, ptr));
    return env3.createValue(res, result);
  },
  napi_create_external_buffer(env_id, length, data, finalize_cb, finalize_hint, result) {
    let env3 = environments[env_id];
    let buf2 = typeof globalThis.Buffer !== "undefined" ? globalThis.Buffer.from(env3.memory.buffer, data, length) : env3.memory.subarray(data, data + length);
    if (finalize_cb) {
      let cb = env3.table.get(finalize_cb);
      finalizationRegistry.register(buf2, new FinalizeRecord(env_id, cb, finalize_hint, data));
    }
    return env3.createValue(buf2, result);
  },
  napi_get_buffer_info(env_id, value, data, length) {
    let env3 = environments[env_id];
    let buf2 = env3.get(value);
    let len = env3.getBufferInfo(buf2, data);
    return env3.setPointer(length, len);
  },
  napi_create_arraybuffer(env_id, length, data, result) {
    let env3 = environments[env_id];
    let buf2 = new ArrayBuffer(length);
    if (data) {
      env3.getBufferInfo(buf2, data);
    }
    return env3.createValue(buf2, result);
  },
  napi_create_external_arraybuffer(env_id, data, length, finalize_cb, finalize_hint, result) {
    return NAPI_NO_EXTERNAL_BUFFERS_ALLOWED;
  },
  napi_get_arraybuffer_info(env_id, value, data, length) {
    let env3 = environments[env_id];
    let len = env3.getBufferInfo(env3.get(value), data);
    return env3.setPointer(length, len);
  },
  napi_detach_arraybuffer(env_id, arraybuffer) {
    let env3 = environments[env_id];
    let buffer = env3.get(arraybuffer);
    if (typeof structuredClone === "function") {
      structuredClone(buffer, { transfer: [buffer] });
    }
    return NAPI_OK;
  },
  napi_is_detached_arraybuffer(env_id, arraybuffer, result) {
    let env3 = environments[env_id];
    let buffer = env3.get(arraybuffer);
    env3.memory[result] = buffer.byteLength === 0 ? 1 : 0;
    return NAPI_OK;
  },
  napi_create_typedarray(env_id, type, length, arraybuffer, offset, result) {
    let env3 = environments[env_id];
    let Class = typedArrays[type];
    let buffer = env3.get(arraybuffer);
    let buf2 = new Class(buffer, offset, length);
    return env3.createValue(buf2, result);
  },
  napi_create_dataview(env_id, byte_length, arraybuffer, byte_offset, result) {
    let env3 = environments[env_id];
    let buffer = env3.get(arraybuffer);
    let view = new DataView(buffer, byte_offset, byte_length);
    return env3.createValue(view, result);
  },
  napi_get_typedarray_info(env_id, typedarray, type, length, data, arraybuffer, byte_offset) {
    let env3 = environments[env_id];
    let val = env3.get(typedarray);
    env3.setPointer(type, typedArrays.findIndex((constructor) => val instanceof constructor));
    env3.setPointer(length, val.length);
    env3.getBufferInfo(val, data);
    env3.createValue(val.buffer, arraybuffer);
    return env3.setPointer(byte_offset, val.byteOffset);
  },
  napi_get_dataview_info(env_id, dataview, byte_length, data, arraybuffer, byte_offset) {
    let env3 = environments[env_id];
    let val = env3.get(dataview);
    env3.setPointer(byte_length, val.byteLength);
    env3.getBufferInfo(val, data);
    env3.createValue(val.buffer, arraybuffer);
    return env3.setPointer(byte_offset, val.byteOffset);
  },
  napi_create_string_utf8(env_id, str, length, result) {
    let env3 = environments[env_id];
    let s = decoder.decode(env3.memory.subarray(str, str + length));
    return env3.createValue(s, result);
  },
  napi_get_value_string_utf8(env_id, value, buf2, bufsize, result) {
    let env3 = environments[env_id];
    let val = env3.get(value);
    if (typeof val !== "string") {
      return NAPI_STRING_EXPECTED;
    }
    if (buf2 == 0) {
      return env3.setPointer(result, utf8Length(val));
    }
    let res = encoder.encodeInto(val, env3.memory.subarray(buf2, buf2 + bufsize - 1));
    env3.memory[buf2 + res.written] = 0;
    return env3.setPointer(result, res.written);
  },
  napi_create_string_latin1(env_id, str, length, result) {
    let env3 = environments[env_id];
    let s = latin1Decoder.decode(env3.memory.subarray(str, str + length));
    return env3.createValue(s, result);
  },
  napi_get_value_string_latin1(env_id, value, buf2, bufsize, result) {
    let env3 = environments[env_id];
    let val = env3.get(value);
    if (typeof val !== "string") {
      return NAPI_STRING_EXPECTED;
    }
    if (buf2 == 0) {
      return env3.setPointer(result, val.length);
    }
    let mem = env3.memory;
    let len = Math.min(val.length, bufsize - 1);
    for (let i = 0; i < len; i++) {
      let code = val.charCodeAt(i);
      mem[buf2++] = code;
    }
    mem[buf2] = 0;
    return env3.setPointer(result, len);
  },
  napi_create_string_utf16(env_id, str, length, result) {
    let env3 = environments[env_id];
    let s = utf16Decoder.decode(env3.memory.subarray(str, str + length * 2));
    return env3.createValue(s, result);
  },
  napi_get_value_string_utf16(env_id, value, buf2, bufsize, result) {
    let env3 = environments[env_id];
    let val = env3.get(value);
    if (typeof val !== "string") {
      return NAPI_STRING_EXPECTED;
    }
    if (buf2 == 0) {
      return env3.setPointer(result, val.length);
    }
    let mem = env3.u16;
    let ptr = buf2 >> 1;
    let len = Math.min(val.length, bufsize - 1);
    for (let i = 0; i < len; i++) {
      let code = val.charCodeAt(i);
      mem[ptr++] = code;
    }
    mem[ptr] = 0;
    return env3.setPointer(result, len);
  },
  napi_create_date(env_id, time, result) {
    let env3 = environments[env_id];
    return env3.createValue(new Date(time), result);
  },
  napi_get_date_value(env_id, value, result) {
    let env3 = environments[env_id];
    let date = env3.get(value);
    env3.f64[result >> 3] = date.valueOf();
  },
  napi_create_symbol(env_id, description, result) {
    let env3 = environments[env_id];
    let desc = env3.get(description);
    return env3.createValue(Symbol(desc), result);
  },
  napi_coerce_to_bool(env_id, value, result) {
    let env3 = environments[env_id];
    return env3.createValue(Boolean(env3.get(value)), result);
  },
  napi_coerce_to_number(env_id, value, result) {
    let env3 = environments[env_id];
    return env3.createValue(Number(env3.get(value)), result);
  },
  napi_coerce_to_object(env_id, value, result) {
    let env3 = environments[env_id];
    return env3.createValue(Object(env3.get(value)), result);
  },
  napi_coerce_to_string(env_id, value, result) {
    let env3 = environments[env_id];
    return env3.createValue(String(env3.get(value)), result);
  },
  napi_typeof(env_id, value, result) {
    let env3 = environments[env_id];
    let val = env3.get(value);
    return env3.setPointer(result, (() => {
      switch (typeof val) {
        case "undefined":
          return 0;
        case "boolean":
          return 2;
        case "number":
          return 3;
        case "string":
          return 4;
        case "symbol":
          return 5;
        case "object":
          if (val === null) {
            return 1;
          } else if (val instanceof ExternalValue) {
            return 8;
          }
          return 6;
        case "function":
          return 7;
        case "bigint":
          return 9;
      }
    })());
  },
  napi_instanceof(env_id, object, constructor, result) {
    let env3 = environments[env_id];
    let obj = env3.get(object);
    let cons = env3.get(constructor);
    env3.memory[result] = obj instanceof cons ? 1 : 0;
    return NAPI_OK;
  },
  napi_is_array(env_id, value, result) {
    let env3 = environments[env_id];
    let val = env3.get(value);
    env3.memory[result] = Array.isArray(val) ? 1 : 0;
    return NAPI_OK;
  },
  napi_is_buffer(env_id, value, result) {
    let env3 = environments[env_id];
    let val = env3.get(value);
    env3.memory[result] = (typeof globalThis.Buffer !== "undefined" ? globalThis.Buffer.isBuffer(val) : val instanceof Uint8Array) ? 1 : 0;
    return NAPI_OK;
  },
  napi_is_date(env_id, value, result) {
    let env3 = environments[env_id];
    let val = env3.get(value);
    env3.memory[result] = val instanceof Date ? 1 : 0;
    return NAPI_OK;
  },
  napi_is_error(env_id, value, result) {
    let env3 = environments[env_id];
    let err = env3.get(value);
    env3.memory[result] = err instanceof Error ? 1 : 0;
    return NAPI_OK;
  },
  napi_is_typedarray(env_id, value, result) {
    let env3 = environments[env_id];
    let buf2 = env3.get(value);
    env3.memory[result] = ArrayBuffer.isView(buf2) && !(buf2 instanceof DataView) ? 1 : 0;
    return NAPI_OK;
  },
  napi_is_dataview(env_id, value, result) {
    let env3 = environments[env_id];
    let val = env3.get(value);
    env3.memory[result] = val instanceof DataView ? 1 : 0;
    return NAPI_OK;
  },
  napi_strict_equals(env_id, lhs, rhs, result) {
    let env3 = environments[env_id];
    env3.memory[result] = env3.get(lhs) === env3.get(rhs) ? 1 : 0;
    return NAPI_OK;
  },
  napi_wrap(env_id, js_object, native_object, finalize_cb, finalize_hint, result) {
    let env3 = environments[env_id];
    let obj = env3.get(js_object);
    env3.wrappedObjects.set(obj, native_object);
    if (finalize_cb) {
      let cb = env3.table.get(finalize_cb);
      finalizationRegistry.register(obj, new FinalizeRecord(env_id, cb, finalize_hint, native_object));
    }
    if (result) {
      return napi.napi_create_reference(env_id, js_object, 1, result);
    }
    return NAPI_OK;
  },
  napi_unwrap(env_id, js_object, result) {
    let env3 = environments[env_id];
    let obj = env3.get(js_object);
    let native_object = env3.wrappedObjects.get(obj);
    env3.setPointer(result, native_object);
    return NAPI_OK;
  },
  napi_remove_wrap(env_id, js_object, result) {
    let env3 = environments[env_id];
    let obj = env3.get(js_object);
    let native_object = env3.wrappedObjects.get(obj);
    finalizationRegistry.unregister(obj);
    env3.wrappedObjects.delete(obj);
    return env3.setPointer(result, native_object);
  },
  napi_type_tag_object(env_id, js_object, type_tag) {
    throw new Error("not implemented");
  },
  napi_check_object_type_tag(env_id, js_object, type_tag) {
    throw new Error("not implemented");
  },
  napi_add_finalizer(env_id, js_object, native_object, finalize_cb, finalize_hint, result) {
    let env3 = environments[env_id];
    let obj = env3.get(js_object);
    let cb = env3.table.get(finalize_cb);
    finalizationRegistry.register(obj, new FinalizeRecord(env_id, cb, finalize_hint, native_object));
    if (result) {
      return napi.napi_create_reference(env_id, js_object, 1, result);
    }
    return NAPI_OK;
  },
  napi_create_promise(env_id, deferred, promise) {
    let env3 = environments[env_id];
    let p = new Promise((resolve, reject) => {
      let id = env3.deferred.length;
      env3.deferred.push({ resolve, reject });
      env3.setPointer(deferred, id);
    });
    return env3.createValue(p, promise);
  },
  napi_resolve_deferred(env_id, deferred, resolution) {
    let env3 = environments[env_id];
    let { resolve } = env3.deferred[deferred];
    let value = env3.get(resolution);
    resolve(value);
    env3.deferred[deferred] = void 0;
    return NAPI_OK;
  },
  napi_reject_deferred(env_id, deferred, rejection) {
    let env3 = environments[env_id];
    let { reject } = env3.deferred[deferred];
    let value = env3.get(rejection);
    reject(value);
    env3.deferred[deferred] = void 0;
    return NAPI_OK;
  },
  napi_is_promise(env_id, value, result) {
    let env3 = environments[env_id];
    let val = env3.get(value);
    env3.memory[result] = val instanceof Promise ? 1 : 0;
    return NAPI_OK;
  },
  napi_run_script(env_id, script, result) {
    let env3 = environments[env_id];
    let source = env3.get(script);
    let res = (0, eval)(source);
    return env3.createValue(res, result);
  },
  napi_create_external(env_id, data, finalize_cb, finalize_hint, result) {
    let env3 = environments[env_id];
    let external = new ExternalValue();
    env3.externalObjects.set(external, data);
    if (finalize_cb) {
      let cb = env3.table.get(finalize_cb);
      finalizationRegistry.register(external, new FinalizeRecord(env_id, cb, finalize_hint, data));
    }
    return env3.createValue(external, result);
  },
  napi_get_value_external(env_id, value, result) {
    let env3 = environments[env_id];
    let external = env3.get(value);
    let val = env3.externalObjects.get(external);
    if (!val) {
      return NAPI_INVALID_ARG;
    }
    return env3.setPointer(result, val);
  },
  napi_adjust_external_memory() {
    return NAPI_OK;
  }
};
function strlen(buf2, ptr) {
  let len = 0;
  while (buf2[ptr] !== 0) {
    len++;
    ptr++;
  }
  return len;
}
function utf8Length(string) {
  let len = 0;
  for (let i = 0; i < string.length; i++) {
    let c = string.charCodeAt(i);
    if (c >= 55296 && c <= 56319 && i < string.length - 1) {
      let c2 = string.charCodeAt(++i);
      if ((c2 & 64512) === 56320) {
        c = ((c & 1023) << 10) + (c2 & 1023) + 65536;
      } else {
        i--;
      }
    }
    if ((c & 4294967168) === 0) {
      len++;
    } else if ((c & 4294965248) === 0) {
      len += 2;
    } else if ((c & 4294901760) === 0) {
      len += 3;
    } else if ((c & 4292870144) === 0) {
      len += 4;
    }
  }
  return len;
}

// ../../../../../tmp/native-css-fix-20261111/built-wasm-fix3/async.mjs
var cur_await_promise_sync;
function await_promise_sync(promise_addr, result_addr, error_addr) {
  cur_await_promise_sync(promise_addr, result_addr, error_addr);
}
var State = {
  None: 0,
  Unwinding: 1,
  Rewinding: 2
};
function createBundleAsync(env3) {
  let { instance: instance2, exports: exports2 } = env3;
  let { asyncify_get_state, asyncify_start_unwind, asyncify_stop_unwind, asyncify_start_rewind, asyncify_stop_rewind } = instance2.exports;
  let DATA_ADDR = instance2.exports.napi_wasm_malloc(8 + 4096);
  let DATA_START = DATA_ADDR + 8;
  let DATA_END = DATA_ADDR + 8 + 4096;
  new Int32Array(env3.memory.buffer, DATA_ADDR).set([DATA_START, DATA_END]);
  function assertNoneState() {
    if (asyncify_get_state() !== State.None) {
      throw new Error(`Invalid async state ${asyncify_get_state()}, expected 0.`);
    }
  }
  let promise, result, error;
  cur_await_promise_sync = (promise_addr, result_addr, error_addr) => {
    let state = asyncify_get_state();
    if (state === State.Rewinding) {
      asyncify_stop_rewind();
      if (result != null) {
        env3.createValue(result, result_addr);
      }
      if (error != null) {
        env3.createValue(error, error_addr);
      }
      promise = result = error = null;
      return;
    }
    assertNoneState();
    promise = env3.get(promise_addr);
    asyncify_start_unwind(DATA_ADDR);
  };
  return async function bundleAsync2(options) {
    assertNoneState();
    let res = exports2.bundle(options);
    while (asyncify_get_state() === State.Unwinding) {
      asyncify_stop_unwind();
      try {
        result = await promise;
      } catch (err) {
        error = err;
      }
      assertNoneState();
      asyncify_start_rewind(DATA_ADDR);
      res = exports2.bundle(options);
    }
    assertNoneState();
    return res;
  };
}

// ../../../../../tmp/native-css-fix-20261111/built-wasm-fix3/wasm-node.mjs
var import_fs = __toESM(require("fs"), 1);
var import_node_crypto = require("node:crypto");

// ../../../../../tmp/native-css-fix-20261111/built-wasm-fix3/browserslistToTargets.js
var BROWSER_MAPPING = {
  and_chr: "chrome",
  and_ff: "firefox",
  ie_mob: "ie",
  op_mob: "opera",
  and_qq: null,
  and_uc: null,
  baidu: null,
  bb: null,
  kaios: null,
  op_mini: null
};
function browserslistToTargets(browserslist) {
  let targets = {};
  for (let browser of browserslist) {
    let [name, v] = browser.split(" ");
    if (BROWSER_MAPPING[name] === null) {
      continue;
    }
    let version = parseVersion(v);
    if (version == null) {
      continue;
    }
    if (targets[name] == null || version < targets[name]) {
      targets[name] = version;
    }
  }
  return targets;
}
function parseVersion(version) {
  let [major, minor = 0, patch = 0] = version.split("-")[0].split(".").map((v) => parseInt(v, 10));
  if (isNaN(major) || isNaN(minor) || isNaN(patch)) {
    return null;
  }
  return major << 16 | minor << 8 | patch;
}

// ../../../../../tmp/native-css-fix-20261111/built-wasm-fix3/flags.js
var Features = {
  Nesting: 1,
  NotSelectorList: 2,
  DirSelector: 4,
  LangSelectorList: 8,
  IsSelector: 16,
  TextDecorationThicknessPercent: 32,
  MediaIntervalSyntax: 64,
  MediaRangeSyntax: 128,
  CustomMediaQueries: 256,
  ClampFunction: 512,
  ColorFunction: 1024,
  OklabColors: 2048,
  LabColors: 4096,
  P3Colors: 8192,
  HexAlphaColors: 16384,
  SpaceSeparatedColorNotation: 32768,
  FontFamilySystemUi: 65536,
  DoublePositionGradients: 131072,
  VendorPrefixes: 262144,
  LogicalProperties: 524288,
  LightDark: 1048576,
  Selectors: 31,
  MediaQueries: 448,
  Colors: 1113088
};

// ../../../../../tmp/native-css-fix-20261111/built-wasm-fix3/composeVisitors.js
function composeVisitors(visitors) {
  if (visitors.length === 1) {
    return visitors[0];
  }
  if (visitors.some((v) => typeof v === "function")) {
    return (opts) => {
      let v = visitors.map((v2) => typeof v2 === "function" ? v2(opts) : v2);
      return composeVisitors(v);
    };
  }
  let res = {};
  composeSimpleVisitors(res, visitors, "StyleSheet");
  composeSimpleVisitors(res, visitors, "StyleSheetExit");
  composeObjectVisitors(res, visitors, "Rule", ruleVisitor, wrapCustomAndUnknownAtRule);
  composeObjectVisitors(res, visitors, "RuleExit", ruleVisitor, wrapCustomAndUnknownAtRule);
  composeObjectVisitors(res, visitors, "Declaration", declarationVisitor, wrapCustomProperty);
  composeObjectVisitors(res, visitors, "DeclarationExit", declarationVisitor, wrapCustomProperty);
  composeSimpleVisitors(res, visitors, "Url");
  composeSimpleVisitors(res, visitors, "Color");
  composeSimpleVisitors(res, visitors, "Image");
  composeSimpleVisitors(res, visitors, "ImageExit");
  composeSimpleVisitors(res, visitors, "Length");
  composeSimpleVisitors(res, visitors, "Angle");
  composeSimpleVisitors(res, visitors, "Ratio");
  composeSimpleVisitors(res, visitors, "Resolution");
  composeSimpleVisitors(res, visitors, "Time");
  composeSimpleVisitors(res, visitors, "CustomIdent");
  composeSimpleVisitors(res, visitors, "DashedIdent");
  composeArrayFunctions(res, visitors, "MediaQuery");
  composeArrayFunctions(res, visitors, "MediaQueryExit");
  composeSimpleVisitors(res, visitors, "SupportsCondition");
  composeSimpleVisitors(res, visitors, "SupportsConditionExit");
  composeArrayFunctions(res, visitors, "Selector");
  composeTokenVisitors(res, visitors, "Token", "token", false);
  composeTokenVisitors(res, visitors, "Function", "function", false);
  composeTokenVisitors(res, visitors, "FunctionExit", "function", true);
  composeTokenVisitors(res, visitors, "Variable", "var", false);
  composeTokenVisitors(res, visitors, "VariableExit", "var", true);
  composeTokenVisitors(res, visitors, "EnvironmentVariable", "env", false);
  composeTokenVisitors(res, visitors, "EnvironmentVariableExit", "env", true);
  return res;
}
function wrapCustomAndUnknownAtRule(k, f) {
  if (k === "unknown") {
    return ((value) => f({ type: "unknown", value }));
  }
  if (k === "custom") {
    return ((value) => f({ type: "custom", value }));
  }
  return f;
}
function wrapCustomProperty(k, f) {
  return k === "custom" ? ((value) => f({ property: "custom", value })) : f;
}
function ruleVisitor(f, item) {
  if (typeof f === "object") {
    if (item.type === "unknown") {
      let v = f.unknown;
      if (typeof v === "object") {
        v = v[item.value.name];
      }
      return v?.(item.value);
    }
    if (item.type === "custom") {
      let v = f.custom;
      if (typeof v === "object") {
        v = v[item.value.name];
      }
      return v?.(item.value);
    }
    return f[item.type]?.(item);
  }
  return f?.(item);
}
function declarationVisitor(f, item) {
  if (typeof f === "object") {
    let name = item.property;
    if (item.property === "unparsed") {
      name = item.value.propertyId.property;
    } else if (item.property === "custom") {
      let v = f.custom;
      if (typeof v === "object") {
        v = v[item.value.name];
      }
      return v?.(item.value);
    }
    return f[name]?.(item);
  }
  return f?.(item);
}
function extractObjectsOrFunctions(visitors, key) {
  let values = [];
  let hasFunction = false;
  let allKeys = /* @__PURE__ */ new Set();
  for (let visitor of visitors) {
    let v = visitor[key];
    if (v) {
      if (typeof v === "function") {
        hasFunction = true;
      } else {
        for (let key2 in v) {
          allKeys.add(key2);
        }
      }
      values.push(v);
    }
  }
  return [values, hasFunction, allKeys];
}
function composeObjectVisitors(res, visitors, key, apply, wrapKey) {
  let [values, hasFunction, allKeys] = extractObjectsOrFunctions(visitors, key);
  if (values.length === 0) {
    return;
  }
  if (values.length === 1) {
    res[key] = values[0];
    return;
  }
  let f = createArrayVisitor(visitors, (visitor, item) => apply(visitor[key], item));
  if (hasFunction) {
    res[key] = f;
  } else {
    let v = {};
    for (let k of allKeys) {
      v[k] = wrapKey(k, f);
    }
    res[key] = v;
  }
}
function composeTokenVisitors(res, visitors, key, type, isExit) {
  let [values, hasFunction, allKeys] = extractObjectsOrFunctions(visitors, key);
  if (values.length === 0) {
    return;
  }
  if (values.length === 1) {
    res[key] = values[0];
    return;
  }
  let f = createTokenVisitor(visitors, type, isExit);
  if (hasFunction) {
    res[key] = f;
  } else {
    let v = {};
    for (let key2 of allKeys) {
      v[key2] = f;
    }
    res[key] = v;
  }
}
function createTokenVisitor(visitors, type, isExit) {
  let v = createArrayVisitor(visitors, (visitor, item) => {
    let f;
    switch (item.type) {
      case "token":
        f = visitor.Token;
        if (typeof f === "object") {
          f = f[item.value.type];
        }
        break;
      case "function":
        f = isExit ? visitor.FunctionExit : visitor.Function;
        if (typeof f === "object") {
          f = f[item.value.name];
        }
        break;
      case "var":
        f = isExit ? visitor.VariableExit : visitor.Variable;
        break;
      case "env":
        f = isExit ? visitor.EnvironmentVariableExit : visitor.EnvironmentVariable;
        if (typeof f === "object") {
          let name;
          switch (item.value.name.type) {
            case "ua":
            case "unknown":
              name = item.value.name.value;
              break;
            case "custom":
              name = item.value.name.ident;
              break;
          }
          f = f[name];
        }
        break;
      case "color":
        f = visitor.Color;
        break;
      case "url":
        f = visitor.Url;
        break;
      case "length":
        f = visitor.Length;
        break;
      case "angle":
        f = visitor.Angle;
        break;
      case "time":
        f = visitor.Time;
        break;
      case "resolution":
        f = visitor.Resolution;
        break;
      case "dashed-ident":
        f = visitor.DashedIdent;
        break;
    }
    if (!f) {
      return;
    }
    let res = f(item.value);
    switch (item.type) {
      case "color":
      case "url":
      case "length":
      case "angle":
      case "time":
      case "resolution":
      case "dashed-ident":
        if (Array.isArray(res)) {
          res = res.map((value) => ({ type: item.type, value }));
        } else if (res) {
          res = { type: item.type, value: res };
        }
        break;
    }
    return res;
  });
  return (value) => v({ type, value });
}
function extractFunctions(visitors, key) {
  let functions = [];
  for (let visitor of visitors) {
    let f = visitor[key];
    if (f) {
      functions.push(f);
    }
  }
  return functions;
}
function composeSimpleVisitors(res, visitors, key) {
  let functions = extractFunctions(visitors, key);
  if (functions.length === 0) {
    return;
  }
  if (functions.length === 1) {
    res[key] = functions[0];
    return;
  }
  res[key] = (arg) => {
    let mutated = false;
    for (let f of functions) {
      let res2 = f(arg);
      if (res2) {
        arg = res2;
        mutated = true;
      }
    }
    return mutated ? arg : void 0;
  };
}
function composeArrayFunctions(res, visitors, key) {
  let functions = extractFunctions(visitors, key);
  if (functions.length === 0) {
    return;
  }
  if (functions.length === 1) {
    res[key] = functions[0];
    return;
  }
  res[key] = createArrayVisitor(functions, (f, item) => f(item));
}
function createArrayVisitor(visitors, apply) {
  let seen = new Bitset(visitors.length);
  return (arg) => {
    let arr = [arg];
    let mutated = false;
    seen.clear();
    for (let i = 0; i < arr.length; i++) {
      for (let v = 0; v < visitors.length && i < arr.length; ) {
        if (seen.get(v)) {
          v++;
          continue;
        }
        let item = arr[i];
        let visitor = visitors[v];
        let res = apply(visitor, item);
        if (Array.isArray(res)) {
          if (res.length === 0) {
            arr.splice(i, 1);
          } else if (res.length === 1) {
            arr[i] = res[0];
          } else {
            arr.splice(i, 1, ...res);
          }
          mutated = true;
          seen.set(v);
          v = 0;
        } else if (res) {
          arr[i] = res;
          mutated = true;
          seen.set(v);
          v = 0;
        } else {
          v++;
        }
      }
    }
    if (!mutated) {
      return;
    }
    return arr.length === 1 ? arr[0] : arr;
  };
}
var Bitset = class {
  constructor(maxBits = 32) {
    this.bits = 0;
    this.more = maxBits > 32 ? new Uint32Array(Math.ceil((maxBits - 32) / 32)) : null;
  }
  /** @param {number} bit */
  get(bit) {
    if (bit >= 32 && this.more) {
      let i = Math.floor((bit - 32) / 32);
      let b = bit % 32;
      return Boolean(this.more[i] & 1 << b);
    } else {
      return Boolean(this.bits & 1 << bit);
    }
  }
  /** @param {number} bit */
  set(bit) {
    if (bit >= 32 && this.more) {
      let i = Math.floor((bit - 32) / 32);
      let b = bit % 32;
      this.more[i] |= 1 << b;
    } else {
      this.bits |= 1 << bit;
    }
  }
  clear() {
    this.bits = 0;
    if (this.more) {
      this.more.fill(0);
    }
  }
};

// ../../../../../tmp/native-css-fix-20261111/built-wasm-fix3/wasm-node.mjs
var wasmBytes = import_fs.default.readFileSync(new URL("lightningcss_node.wasm", import_meta_url));
var wasmModule = new WebAssembly.Module(wasmBytes);
var instance = new WebAssembly.Instance(wasmModule, {
  env: {
    ...napi,
    await_promise_sync,
    __getrandom_v03_custom: (ptr, len) => {
      let buf2 = env2.memory.subarray(ptr, ptr + len);
      import_node_crypto.webcrypto.getRandomValues(buf2);
    }
  }
});
instance.exports.register_module();
var env2 = new Environment(instance);
var wasm = env2.exports;
var bundleAsyncInternal = createBundleAsync(env2);
async function init() {
}
function transform(options) {
  return wrap(wasm.transform, options);
}
function transformStyleAttribute(options) {
  return wrap(wasm.transformStyleAttribute, options);
}
function bundle(options) {
  return wrap(wasm.bundle, {
    ...options,
    resolver: {
      read: (filePath) => import_fs.default.readFileSync(filePath, "utf8")
    }
  });
}
async function bundleAsync(options) {
  if (!options.resolver?.read) {
    options.resolver = {
      ...options.resolver,
      read: (filePath) => import_fs.default.readFileSync(filePath, "utf8")
    };
  }
  return wrap(bundleAsyncInternal, options);
}
function wrap(call, options) {
  if (typeof options.visitor === "function") {
    let deps = [];
    options.visitor = options.visitor({
      addDependency(dep) {
        deps.push(dep);
      }
    });
    let result = call(options);
    if (result instanceof Promise) {
      result = result.then((res) => {
        if (deps.length) {
          res.dependencies ??= [];
          res.dependencies.push(...deps);
        }
        return res;
      });
    } else if (deps.length) {
      result.dependencies ??= [];
      result.dependencies.push(...deps);
    }
    return result;
  } else {
    return call(options);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  Features,
  browserslistToTargets,
  bundle,
  bundleAsync,
  composeVisitors,
  transform,
  transformStyleAttribute
});
